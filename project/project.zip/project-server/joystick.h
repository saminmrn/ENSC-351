// Joystick.h provides the direction in which the joystick is pressed
#ifndef _JOYSTICK_H_
#define _JOYSTICK_H_

void joystick_init();
void joystick_cleanup();

#endif