#ifndef _MAIN_TIMER_H_
#define _MAIN_TIMER_H_

//this is the function to be called to start the main timer
void main_timer();
//this is called when we command the whole program to shut down 
void main_timer_shutdown();

void main_init();
#endif