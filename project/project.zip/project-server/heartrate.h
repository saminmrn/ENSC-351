#ifndef _HEARTRATE_H_
#define _HEARTRATE_H_


void start_heartrate();
void cleanup_heartrate();
int getHeartRate();

#endif