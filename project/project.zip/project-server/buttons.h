// functions to start and end the buttons scanning thread
#ifndef _BUTTONS_H_
#define _BUTTONS_H_

void buttons_init();
void buttons_cleanup();
int get_mode_grey(); 

#endif