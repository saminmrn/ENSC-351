// start and shutdown the printing thread
#ifndef _PRINTING_H_
#define _PRINTING_H_

void printing_init();
void printing_cleanup();

#endif