// control volume and tempo
#ifndef _PLAY_SOUND_HANDLER_H_
#define _PLAY_SOUND_HANDLER_H_

void increaseVolume();
void decreaseVolume();
void increaseTempo();
void decreaseTempo();
int getNewVolume();
int getNewTempo();

#endif