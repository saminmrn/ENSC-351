#ifndef _SHAREDMEM_LINUX_H_
#define _SHAREDMEM_LINUX_H_

void get_user_input(); 
void runCommand(char *command); 

#endif