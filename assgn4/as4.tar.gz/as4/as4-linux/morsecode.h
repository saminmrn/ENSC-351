#ifndef _MORSECODE_H_
#define _MORSECODE_H_

unsigned short MorseCode_getFlashCode(char ch);

#endif