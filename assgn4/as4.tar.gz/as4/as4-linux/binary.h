//function to change the morsecode to a binary array
#ifndef _BINARY_H_
#define _BINARY_H_
#include <stdbool.h>

bool *Binary(int character_code, int *size);


#endif